#!/bin/bash
#SBATCH --job-name=Si
#SBATCH --output=Si.x
#SBATCH --error=Si.x
#SBATCH --nodes=1   
#SBATCH --ntasks=1
#SBATCH --time=2:00:00 
#SBATCH --partition=gpu2
#SBATCH --nodelist=n014

export FLASH=1

echo "SLURM_NTASKS: $SLURM_NTASKS"

source ~/.bash_profile

if [ -z "$SLURM_NTASKS" ] || [ "$SLURM_NTASKS" -le 0 ]; then
	echo "Error: SLURM_NTASKS is not set or is less than or equal to 0"
	exit 1
fi


source $CTE_VENV/bin/activate

sleep 10

cte2-run ./config.yaml
